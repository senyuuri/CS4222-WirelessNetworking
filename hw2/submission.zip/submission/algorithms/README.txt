count_step requires numpy and matplotlib.

To install the dependencies, simply run:
pip install -r requirements.txt